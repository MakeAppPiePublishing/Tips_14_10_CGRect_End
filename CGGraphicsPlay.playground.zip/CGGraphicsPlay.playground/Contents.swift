import UIKit

class ViewController:UIViewController{
    var imageView1 = UIImageView()
    var imageView2 = UIImageView()
    
    func drawStuff(){
        
    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        imageView1.frame = view.bounds
        imageView1.backgroundColor = .blue
        view.addSubview(imageView1)
        //imageView2.frame = CGRect(origin: CGPoint(x: view.bounds.midX, y: view.bounds.midY), size: CGSize(width: 150, height: 100))
        imageView2.frame = imageView1.bounds.insetBy(dx: 20, dy: 20)
        imageView2.backgroundColor = .green
        view.addSubview(imageView2)
        drawStuff()
    }
    
    override func loadView(){
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
     
        view.backgroundColor = .systemBackground
        self.view = view
    }
}

import PlaygroundSupport
let vc = ViewController()
PlaygroundPage.current.setLiveView(vc)
